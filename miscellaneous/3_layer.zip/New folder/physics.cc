#include "physics.hh"

#include "G4DecayPhysics.hh"
#include "G4RadioactiveDecayPhysics.hh"
#include "G4EmStandardPhysics.hh"
#include "G4OpticalPhysics.hh"

MyPhysicsList::MyPhysicsList() {
    // Electromagnetic interactions
    // Handles muon energy loss via ionization, multiple scattering, bremsstrahlung, and pair production
    RegisterPhysics(new G4EmStandardPhysics());

    // Optical physics (optional)
    // Relevant for Cherenkov radiation or scintillation, generally less important for LHC muons
    // RegisterPhysics(new G4OpticalPhysics());

    // Decay physics
    // Handles muon decay in flight: 
    //   μ⁻ → e⁻ + ν̄ₑ + ν_μ
    //   μ⁺ → e⁺ + νₑ + ν̄_μ
    RegisterPhysics(new G4DecayPhysics());

    // Radioactive decay physics (optional)
    // Not directly relevant for stable muons, but included for completeness/backgrounds
    // RegisterPhysics(new G4RadioactiveDecayPhysics());
}

MyPhysicsList::~MyPhysicsList() {}

