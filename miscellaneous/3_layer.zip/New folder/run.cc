#include "run.hh"

MyRunAction::MyRunAction()
{
    G4AnalysisManager* man = G4AnalysisManager::Instance();
    
    // Create ParticleTracking ntuple (ID = 0) - matching CSV columns exactly
    man->CreateNtuple("ParticleTracking", "Particle Tracking Data");
    man->CreateNtupleIColumn("track_id");              // Column 0
    man->CreateNtupleIColumn("layer");                 // Column 1
    man->CreateNtupleDColumn("energy_before_MeV");     // Column 2
    man->CreateNtupleDColumn("energy_after_MeV");      // Column 3
    man->CreateNtupleDColumn("energy_deposited_MeV");  // Column 4
    man->CreateNtupleDColumn("px_before_MeV");         // Column 5
    man->CreateNtupleDColumn("py_before_MeV");         // Column 6
    man->CreateNtupleDColumn("pz_before_MeV");         // Column 7
    man->CreateNtupleDColumn("px_after_MeV");          // Column 8
    man->CreateNtupleDColumn("py_after_MeV");          // Column 9
    man->CreateNtupleDColumn("pz_after_MeV");          // Column 10
    man->CreateNtupleDColumn("x_enter_mm");            // Column 11
    man->CreateNtupleDColumn("y_enter_mm");            // Column 12
    man->CreateNtupleDColumn("z_enter_mm");            // Column 13
    man->CreateNtupleDColumn("x_exit_mm");             // Column 14
    man->CreateNtupleDColumn("y_exit_mm");             // Column 15
    man->CreateNtupleDColumn("z_exit_mm");             // Column 16
    man->CreateNtupleIColumn("particle_id");           // Column 17

    man->FinishNtuple(0);
}

MyRunAction::~MyRunAction()
{
}

void MyRunAction::BeginOfRunAction(const G4Run* run)
{
    G4AnalysisManager* man = G4AnalysisManager::Instance();
    G4int runID = run->GetRunID();
    std::stringstream strRunID;
    strRunID << runID;
    man->OpenFile("output"+strRunID.str()+".root");
}

void MyRunAction::EndOfRunAction(const G4Run*)
{
    G4AnalysisManager* man = G4AnalysisManager::Instance();
    man->Write();
    man->CloseFile();
}
