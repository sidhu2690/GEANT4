#include "construction.hh"
#include "detector.hh"  
#include "G4UserLimits.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include "G4SDManager.hh" 

MyDetectorConstruction::MyDetectorConstruction() {}
MyDetectorConstruction::~MyDetectorConstruction() {}

G4VPhysicalVolume* MyDetectorConstruction::Construct() {
    G4NistManager* nist = G4NistManager::Instance();

    // ---------------------
    // World volume: 1m x 1m x 2m
    // ---------------------
    G4Material* worldMat = nist->FindOrBuildMaterial("G4_Galactic");
    G4Box* solidWorld = new G4Box("solidWorld", 0.5*m, 0.5*m, 1.0*m);
    G4LogicalVolume* logicWorld = new G4LogicalVolume(solidWorld, worldMat, "logicWorld");

    G4VPhysicalVolume* physWorld = new G4PVPlacement(
        0,                      
        G4ThreeVector(0,0,0),   
        logicWorld,             
        "physWorld",            
        0,                      
        false,                  
        0,                      
        true                    
    );

    // ---------------------
    // Scintillator material
    // ---------------------
    G4Material* scintMat = nist->FindOrBuildMaterial("G4_PLASTIC_SC_VINYLTOLUENE");

    // ---------------------
    // Individual pixel definition (1cm x 1cm x 1cm)
    // ---------------------
    G4Box* solidPixel = new G4Box("solidPixel", 0.5*cm, 0.5*cm, 0.5*cm);
    G4LogicalVolume* logicPixel = new G4LogicalVolume(solidPixel, scintMat, "logicPixel");
	
     // Step legnth logic
    //G4double maxStep = 1*mm;  
   //logicPixel->SetUserLimits(new G4UserLimits(maxStep));



    // ---------------------
    // Create and attach sensitive detector to pixel logical volume
    // ---------------------
    MySensitiveDetector* sensDet = new MySensitiveDetector("PixelDetector");
    G4SDManager* SDman = G4SDManager::GetSDMpointer();
    SDman->AddNewDetector(sensDet);
    logicPixel->SetSensitiveDetector(sensDet);



    // ---------------------
    // Place pixels in a 80x80 grid for each layer
    // ---------------------
    G4double layerPositions[3] = {0.4*m, 0.6*m, 0.8*m};
    
    for (int layer = 0; layer < 3; layer++) {
        for (int ix = 0; ix < 80; ix++) {
            for (int iy = 0; iy < 80; iy++) {
                G4double x_pos = -39.5*cm + ix*cm;
                G4double y_pos = -39.5*cm + iy*cm;
                G4double z_pos = layerPositions[layer];

                G4int copyNumber = layer*10000 + ix*100 + iy;

                new G4PVPlacement(
                    0,                                    
                    G4ThreeVector(x_pos, y_pos, z_pos),  
                    logicPixel,                           
                    "physPixel",                          
                    logicWorld,                           
                    false,                                
                    copyNumber,                           
                    false                                 
                );
            }
        }
    }

    return physWorld;
}
