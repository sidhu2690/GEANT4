#ifndef DETECTOR_HH
#define DETECTOR_HH

#include "G4VSensitiveDetector.hh"
#include "G4HCofThisEvent.hh"
#include "G4Step.hh"
#include "G4TouchableHistory.hh"
#include "G4Track.hh"
#include "G4ThreeVector.hh"
#include <map>
#include <set>

// Structure to hold particle data for each track-layer combination
struct ParticleData {
    G4int trackID;
    G4int layer;
    G4int particleID;
    G4double energyBefore;
    G4double energyAfter;
    G4double totalEnergyDeposited;
    G4ThreeVector momentumBefore;
    G4ThreeVector momentumAfter;
    G4ThreeVector positionEnter;
    G4ThreeVector positionExit;
    bool hasEntryData;
    bool hasExitData;
    
 
};

class MySensitiveDetector : public G4VSensitiveDetector {
public:
    MySensitiveDetector(const G4String& name);
    virtual ~MySensitiveDetector();
    
    virtual void Initialize(G4HCofThisEvent* hce) override;
    virtual G4bool ProcessHits(G4Step* step, G4TouchableHistory* history) override;
    virtual void EndOfEvent(G4HCofThisEvent* hce) override;
    
private:
    // Map to store particle data: key = "trackID_layer"
    std::map<std::string, ParticleData> fParticleData;
    
    // Set to keep track of processed track-layer combinations
    std::set<std::string> fProcessedTrackLayers;
    
    // Helper function to write data to ROOT ntuple
    void WriteParticleData(const ParticleData& data);
};

#endif
