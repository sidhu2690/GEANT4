#include "generator.hh"
#include "Randomize.hh"               // for G4RandFlat::shoot
#include "CLHEP/Units/PhysicalConstants.h" // for CLHEP::pi
#include "G4SystemOfUnits.hh"

MyPrimaryGenerator::MyPrimaryGenerator() {
    fParticleGun = new G4ParticleGun(1); // single particle per gun call
}

MyPrimaryGenerator::~MyPrimaryGenerator() {
    delete fParticleGun;
}

void MyPrimaryGenerator::GeneratePrimaries(G4Event* anEvent) {
    G4ParticleTable* particleTable = G4ParticleTable::GetParticleTable();
    G4ParticleDefinition* muon = particleTable->FindParticle("mu+"); // positive muon

    // ---- Geometry info ----
    // Source plane: z = 0 cm
    // Detector extends to z = 0.8 m = 80 cm
    // Half-width of detector: 40 cm
    // Max displacement: Δx (or Δy) = 40 cm over Δz = 80 cm
    // θmax = atan(40/80) rad 
    // But we will be using only 80% this value


    G4double ratio = 0.4 / 0.8;
    G4double thetaMax = std::atan(0.8 * ratio); // in radians

    for (int i = 0; i < 100; i++) {
        // Position: x, y uniform in [0.0] cm, z = 0 cm
        G4double x = G4RandFlat::shoot(0.0) * cm;
        G4double y = G4RandFlat::shoot(0.0) * cm;
        G4double z = 0.0 * cm;

        // Total Momentum magnitude (10 GeV)
        G4double pTot = 10.0 * GeV;;

        // Sample theta within acceptance cone
        // Use cos(theta) to ensure uniform solid-angle distribution
        G4double cosThetaMin = std::cos(thetaMax);
        G4double cosTheta    = 1.0 - (1.0 - cosThetaMin) * G4RandFlat::shoot(0., 1.);
        G4double theta       = std::acos(cosTheta);

        // Azimuthal angle
        G4double phi = G4RandFlat::shoot(0., 2. * CLHEP::pi);

        // Momentum components
        G4double px = pTot * std::sin(theta) * std::cos(phi);
        G4double py = pTot * std::sin(theta) * std::sin(phi);
        G4double pz = pTot * std::cos(theta);

        // Configure particle gun
        fParticleGun->SetParticleDefinition(muon);
        fParticleGun->SetParticlePosition(G4ThreeVector(x, y, z));
        fParticleGun->SetParticleMomentumDirection(G4ThreeVector(px, py, pz).unit());
        fParticleGun->SetParticleMomentum(pTot);

        // Fire
        fParticleGun->GeneratePrimaryVertex(anEvent);
    }
}
