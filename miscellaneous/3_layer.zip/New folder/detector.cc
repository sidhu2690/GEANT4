#include "detector.hh"
#include "G4Step.hh"
#include "G4Track.hh"
#include "G4StepPoint.hh"
#include "G4ThreeVector.hh"
#include "G4SystemOfUnits.hh"
#include "G4ios.hh"
#include "G4RunManager.hh"
#include "G4AnalysisManager.hh"

MySensitiveDetector::MySensitiveDetector(const G4String& name) 
    : G4VSensitiveDetector(name)
{
    // Constructor
}

MySensitiveDetector::~MySensitiveDetector()
{
    // Destructor
}

void MySensitiveDetector::Initialize(G4HCofThisEvent* hce)
{
    // Initialize for new event - clear temporary data if needed
    fParticleData.clear();
    fProcessedTrackLayers.clear();
}

G4bool MySensitiveDetector::ProcessHits(G4Step* step, G4TouchableHistory* history)
{
    if (!step) return false;
    
    G4Track* track = step->GetTrack();
    if (!track) return false;
    
    G4int trackID = track->GetTrackID();
    G4int particleID = track->GetDefinition()->GetPDGEncoding();
    
    // Get pre and post step points
    const G4StepPoint* preStepPoint = step->GetPreStepPoint();
    const G4StepPoint* postStepPoint = step->GetPostStepPoint();
    
    if (!preStepPoint || !postStepPoint) return false;
    
    // Get the copy number of the current pixel
    G4int copyNumber = preStepPoint->GetTouchable()->GetCopyNumber();
    G4int layer = copyNumber / 10000;
    
    // Create unique key for this track-layer combination
    std::string trackLayerKey = std::to_string(trackID) + "_" + std::to_string(layer);
    
    // Check if this is the first step in this pixel
    if (track->GetCurrentStepNumber() == 1 || 
        (fParticleData.find(trackLayerKey) == fParticleData.end() && 
         fProcessedTrackLayers.find(trackLayerKey) == fProcessedTrackLayers.end())) {
        
        // New particle entering this pixel or secondary born in pixel
        ParticleData& data = fParticleData[trackLayerKey];
        data.trackID = trackID;
        data.layer = layer;
        data.particleID = particleID;
        data.energyBefore = preStepPoint->GetKineticEnergy();
        data.momentumBefore = preStepPoint->GetMomentum();
        data.positionEnter = preStepPoint->GetPosition();
        data.hasEntryData = true;
        data.totalEnergyDeposited = 0.0;
 
    }
    
    // Accumulate energy deposited
    if (fParticleData.find(trackLayerKey) != fParticleData.end()) {
        fParticleData[trackLayerKey].totalEnergyDeposited += step->GetTotalEnergyDeposit();
        
        // Update exit information (will be overwritten each step until particle leaves)
        ParticleData& data = fParticleData[trackLayerKey];
        data.energyAfter = postStepPoint->GetKineticEnergy();
        data.momentumAfter = postStepPoint->GetMomentum();
        data.positionExit = postStepPoint->GetPosition();
        data.hasExitData = true;
    }
    
    // Check if particle is leaving the volume or stopping
    G4StepStatus postStepStatus = postStepPoint->GetStepStatus();
    bool isLeavingVolume = (postStepStatus == fGeomBoundary);
    bool isStoppingInVolume = (track->GetTrackStatus() != fAlive);
    
    if ((isLeavingVolume || isStoppingInVolume) && 
        fParticleData.find(trackLayerKey) != fParticleData.end()) {
        
        ParticleData& data = fParticleData[trackLayerKey];
        
        // Only write data if particle exits (not if it stops inside)
        if (isLeavingVolume && data.hasExitData) {
            WriteParticleData(data);
        }
        
        // Mark as processed and clean up
        fProcessedTrackLayers.insert(trackLayerKey);
        fParticleData.erase(trackLayerKey);
    }
    
    return true;
}

void MySensitiveDetector::EndOfEvent(G4HCofThisEvent* hce)
{
    // Write any remaining data for particles that didn't exit normally
    // (This handles particles that may have stopped at the end of event)
    for (auto& pair : fParticleData) {
        if (pair.second.hasEntryData && pair.second.hasExitData) {
            WriteParticleData(pair.second);
        }
    }
    
    // Clear data for next event
    fParticleData.clear();
    fProcessedTrackLayers.clear();
}

void MySensitiveDetector::WriteParticleData(const ParticleData& data)
{
    // Get the analysis manager instance
    G4AnalysisManager* man = G4AnalysisManager::Instance();
    
    // Fill the ParticleTracking ntuple (ID = 0)
    man->FillNtupleIColumn(0, 0, data.trackID);
    man->FillNtupleIColumn(0, 1, data.layer);
    man->FillNtupleDColumn(0, 2, data.energyBefore/MeV);
    man->FillNtupleDColumn(0, 3, data.energyAfter/MeV);
    man->FillNtupleDColumn(0, 4, data.totalEnergyDeposited/MeV);
    man->FillNtupleDColumn(0, 5, data.momentumBefore.x()/MeV);
    man->FillNtupleDColumn(0, 6, data.momentumBefore.y()/MeV);
    man->FillNtupleDColumn(0, 7, data.momentumBefore.z()/MeV);
    man->FillNtupleDColumn(0, 8, data.momentumAfter.x()/MeV);
    man->FillNtupleDColumn(0, 9, data.momentumAfter.y()/MeV);
    man->FillNtupleDColumn(0, 10, data.momentumAfter.z()/MeV);
    man->FillNtupleDColumn(0, 11, data.positionEnter.x()/mm);
    man->FillNtupleDColumn(0, 12, data.positionEnter.y()/mm);
    man->FillNtupleDColumn(0, 13, data.positionEnter.z()/mm);
    man->FillNtupleDColumn(0, 14, data.positionExit.x()/mm);
    man->FillNtupleDColumn(0, 15, data.positionExit.y()/mm);
    man->FillNtupleDColumn(0, 16, data.positionExit.z()/mm);
    man->FillNtupleIColumn(0, 17, data.particleID);
    
    
    // Add the row to the ntuple
    man->AddNtupleRow(0);
}
